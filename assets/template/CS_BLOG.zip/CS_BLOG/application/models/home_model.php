<?php 

class home_model extends CI_model{
	
	function user_data(){
		$u_data = array(
		'name'=>'Nasrullah',
		'lname'=>'ahadi'
		
		);
		return $u_data;
	}
}
